-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema estudo_db
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema estudo_db
-- -----------------------------------------------------
DROP DATABASE IF EXISTS `estudo_db`;
CREATE SCHEMA IF NOT EXISTS `estudo_db` DEFAULT CHARACTER SET utf8 ;
USE `estudo_db` ;

-- -----------------------------------------------------
-- Table `estudo_db`.`funcionario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `estudo_db`.`funcionario` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NULL,
  `cpf` CHAR(14) NULL,
  `telefone` VARCHAR(20) NULL,
  `email` VARCHAR(255) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `estudo_db`.`ingresso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `estudo_db`.`ingresso` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `tipo` VARCHAR(45) NULL,
  `preco` DECIMAL(8,2) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `estudo_db`.`pedido`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `estudo_db`.`pedido` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `data` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `cliente_id` INT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_pedido_cliente1_idx` (`cliente_id` ASC) VISIBLE,
  CONSTRAINT `fk_pedido_cliente1`
    FOREIGN KEY (`cliente_id`)
    REFERENCES `estudo_db`.`cliente` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `estudo_db`.`ingresso_pedido`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `estudo_db`.`ingresso_pedido` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `agendamento` DATE NULL,
  `preco` DECIMAL(8,2) NULL,
  `usado` TINYINT NULL,
  `ingresso_id` INT NULL,
  `pedido_id` INT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_ingresso_pedido_ingresso1_idx` (`ingresso_id` ASC) VISIBLE,
  INDEX `fk_ingresso_pedido_pedido1_idx` (`pedido_id` ASC) VISIBLE,
  CONSTRAINT `fk_ingresso_pedido_ingresso1`
    FOREIGN KEY (`ingresso_id`)
    REFERENCES `estudo_db`.`ingresso` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ingresso_pedido_pedido1`
    FOREIGN KEY (`pedido_id`)
    REFERENCES `estudo_db`.`pedido` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


SELECT * FROM funcionario;
SELECT * FROM pedido;
SELECT * FROM ingresso;
SELECT * FROM ingresso_pedido;