const express = require('express');
const { PrismaClient } = require('@prisma/client');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const prisma = new PrismaClient({ errorFormat: "minimal" })

app.use(bodyParser.json());
app.use(cors());

// Rotas CRUD para funcionários

// Criar funcionário
app.post('/funcionarios', async (req, res) => {
  const { nome, cpf, telefone, email } = req.body;
  const novoFuncionario = await prisma.funcionario.create({
    data: {
      nome,
      cpf,
      telefone, 
      email
    },
  });
  res.json(novoFuncionario);
});

// Ler todos os funcionários
app.get('/funcionarios', async (req, res) => {
  const funcionarios = await prisma.funcionario.findMany();
  res.json(funcionarios);
});

// Ler um funcionário específico
app.get('/funcionarios/:id', async (req, res) => {
  const { id } = req.params;
  const funcionario = await prisma.funcionario.findUnique({
    where: { id: parseInt(id) },
  });
  res.json(funcionario);
});

// Atualizar funcionário
app.put('/funcionarios/:id', async (req, res) => {
  const { id } = req.params;
  const { nome, cpf, telefone, email } = req.body;
  const funcionarioAtualizado = await prisma.funcionario.update({
    where: { id: parseInt(id) },
    data: {
      nome,
      cpf,
      telefone,
      email
    },
  });
  res.json(funcionarioAtualizado);
});

// Excluir funcionário
app.delete('/funcionarios/:id', async (req, res) => {
  const { id } = req.params;
  const funcionarioApagado = await prisma.funcionario.delete({
    where: { id: parseInt(id) },
  });
  res.json(funcionarioApagado);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Servidor backend rodando na porta ${PORT}`);
});